/*
 * 	Additional function for forms.html
 *	Written by ThemePixels	
 *	http://themepixels.com/
 *
 *	Copyright (c) 2012 ThemePixels (http://themepixels.com)
 *	
 *	Built for Amanda Premium Responsive Admin Template
 *  http://themeforest.net/category/site-templates/admin-templates
 */

jQuery(document).ready(function(){
	
	///// FORM TRANSFORMATION /////
	jQuery('input:checkbox, input:radio, select.uniformselect, input:file').uniform();


	///// DUAL BOX /////学术论文
	var db = jQuery('#academic_select').find('.ds_arrow .arrow');	//get arrows of dual select
	var sel1 = jQuery('#academic_select select:first-child');		//get first select element
	var sel2 = jQuery('#academic_select select:last-child');			//get second select element
	
	sel2.empty(); //empty it first from dom.
	
	db.click(function(){
		var t = (jQuery(this).hasClass('ds_prev'))? 0 : 1;	// 0 if arrow prev otherwise arrow next
		if(t) {
			sel1.find('option').each(function(){
				if(jQuery(this).is(':selected')) {
					jQuery(this).attr('selected',false);
					var op = sel2.find('option:first-child');
					sel2.append(jQuery(this));
				}
			});	
		} else {
			sel2.find('option').each(function(){
				if(jQuery(this).is(':selected')) {
					jQuery(this).attr('selected',false);
					sel1.append(jQuery(this));
				}
			});		
		}
	});
    var preview=jQuery('#preview');
    preview.click(function(){
    	var c=jQuery(sel2)
    })
	
	
		//会议论文
	var db1 = jQuery('#conference_select').find('.ds_arrow .arrow');	//get arrows of dual select
	var selc1 = jQuery('#conference_select select:first-child');		//get first select element
	var selc2 = jQuery('#conference_select select:last-child');			//get second select element
	
	selc2.empty(); //empty it first from dom.
	
	db1.click(function(){
		var t = (jQuery(this).hasClass('ds_prev'))? 0 : 1;	// 0 if arrow prev otherwise arrow next
		if(t) {
			selc1.find('option').each(function(){
				if(jQuery(this).is(':selected')) {
					jQuery(this).attr('selected',false);
					var op = selc2.find('option:first-child');
					selc2.append(jQuery(this));
				}
			});	
		} else {
			selc2.find('option').each(function(){
				if(jQuery(this).is(':selected')) {
					jQuery(this).attr('selected',false);
					selc1.append(jQuery(this));
				}
			});		
		}
	});
		//专利
	var db2 = jQuery('#patent').find('.ds_arrow .arrow');	//get arrows of dual select
	var selp1 = jQuery('#patent select:first-child');		//get first select element
	var selp2 = jQuery('#patent select:last-child');			//get second select element
	
	selp2.empty(); //empty it first from dom.
	
	db2.click(function(){
		var t = (jQuery(this).hasClass('ds_prev'))? 0 : 1;	// 0 if arrow prev otherwise arrow next
		if(t) {
			selp1.find('option').each(function(){
				if(jQuery(this).is(':selected')) {
					jQuery(this).attr('selected',false);
					var op = selp2.find('option:first-child');
					selp2.append(jQuery(this));
				}
			});	
		} else {
			selp2.find('option').each(function(){
				if(jQuery(this).is(':selected')) {
					jQuery(this).attr('selected',false);
					selp1.append(jQuery(this));
				}
			});		
		}
	});
		//项目
	var db3 = jQuery('#project').find('.ds_arrow .arrow');	//get arrows of dual select
	var selpr1 = jQuery('#project select:first-child');		//get first select element
	var selpr2 = jQuery('#project select:last-child');			//get second select element
	
	selpr2.empty(); //empty it first from dom.
	
	db3.click(function(){
		var t = (jQuery(this).hasClass('ds_prev'))? 0 : 1;	// 0 if arrow prev otherwise arrow next
		if(t) {
			selpr1.find('option').each(function(){
				if(jQuery(this).is(':selected')) {
					jQuery(this).attr('selected',false);
					var op = selpr2.find('option:first-child');
					selpr2.append(jQuery(this));
				}
			});	
		} else {
			selpr2.find('option').each(function(){
				if(jQuery(this).is(':selected')) {
					jQuery(this).attr('selected',false);
					selpr1.append(jQuery(this));
				}
			});		
		}
	});
	
	
	var academic_paper=document.getElementById("academic_paper")
	var conference_paper=document.getElementById("conference_paper");
	var patent=document.getElementById("patent");
	var project=document.getElementById("project");
	var show_academic=document.getElementById("show_academic")
	var show_conference=document.getElementById("show_conference");
	var show_patent=document.getElementById("show_patent");
	var show_project=document.getElementById("show_project");
    show_conference.onclick=function(){
    	conference_paper.style.display="block";
    	academic_paper.style.display="none";
    	patent.style.display="none";
    	project.style.display="none";
    	show_conference.setAttribute("class","current");
    	show_academic.setAttribute("class","");
    	show_patent.setAttribute("class","");
    	show_project.setAttribute("class","");
    }
    show_academic.onclick=function(){
    	academic_paper.style.display="block";
    	conference_paper.style.display="none";
    	patent.style.display="none";
    	project.style.display="none";
    	show_academic.setAttribute("class","current");
    	show_conference.setAttribute("class","");
    	show_patent.setAttribute("class","");
    	show_project.setAttribute("class","");
    }
    show_patent.onclick=function(){
    	conference_paper.style.display="none";
    	academic_paper.style.display="none";
    	patent.style.display="block";
    	project.style.display="none";
    	show_conference.setAttribute("class","");
    	show_academic.setAttribute("class","");
    	show_patent.setAttribute("class","current");
    	show_project.setAttribute("class","");
    }
    show_project.onclick=function(){
    	conference_paper.style.display="none";
    	academic_paper.style.display="none";
    	patent.style.display="none";
    	project.style.display="block";
    	show_conference.setAttribute("class","");
    	show_academic.setAttribute("class","");
    	show_patent.setAttribute("class","");
    	show_project.setAttribute("class","current");
    }
	document.getElementById("academic_form").onsubmit = function () {
    var academic_arr = [];
    var academic_op = document.getElementById("academic_choosed").options;
    for (var i = 0; i < academic_op.length; i++){
        academic_arr[i] = academic_op[i].value;
       }
    document.getElementById("academic_hidden").value = academic_arr.join(",");
    }
	
	document.getElementById("conference_form").onsubmit = function () {
    var conference_arr = [];
    var conference_op = document.getElementById("conference_choosed").options;
    for (var k = 0; k < conference_op.length; k++){
        conference_arr[k]= conference_op[k].value;
       }
    document.getElementById("conference_hidden").value = conference_arr.join(",");
    alert(document.getElementById("conference_hidden").value);
    }
	
	document.getElementById("patent_form").onsubmit = function () {
    var patent_arr = [];
    var patent_op = document.getElementById("patent_choosed").options;
    for (var z = 0; z < patent_op.length; z++)
        patent_arr[z] = patent_op[z].value;
    document.getElementById("patent_hidden").value = patent_arr.join(",");
    alert(document.getElementById("patent_hidden").value);
    }
	
	document.getElementById("project_form").onsubmit = function () {
    var project_arr = [];
    var project_op = document.getElementById("project_choosed").options;
    for (var j = 0; j < project_op.length; j++)
        project_arr[j] = project_op[j].value;
    document.getElementById("project_hidden").value = project_arr.join(",");
    alert(document.getElementById("project_hidden").value);
    }
});