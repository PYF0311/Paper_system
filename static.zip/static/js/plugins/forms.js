

//是否授权
var r1=document.getElementById("authorize_cho");
var r2=document.getElementById("authorize_uncho");
var d1=document.getElementById("authorize_time");
r1.onclick=function(){
    d1.style.display="block";
}
r2.onclick=function(){
    d1.style.display="none";
}
//是否转让
var transfer_y=document.getElementById("transfer_y");
var transfer_n=document.getElementById("transfer_n");
var transfer_info=document.getElementById("transfer_info");
transfer_y.onclick=function(){
    transfer_info.style.display="block";
}
transfer_n.onclick=function(){
    transfer_info.style.display="none";
}
//是否发表
var publication_y=document.getElementById("publication_y");
var publication_n=document.getElementById("publication_n");
var c_publication=document.getElementById("c_publication");
publication_y.onclick=function(){
    c_publication.style.display="block";
}
publication_n.onclick=function(){
    c_publication.style.display="none";
   }
var i=0,j=0,k=0,l=0;	
var a=1,b=1,c=1,d=1;
//学术论文
function getName(whichname){
	if(whichname.value){
	var name=whichname.value;
	var t_name=document.getElementById("t_name");
	var t_option=document.createElement("option");
	var t_txt=document.createTextNode(name);
	t_name.appendChild(t_option);
	t_option.appendChild(t_txt)
	}
}
function addAcademic(){
	var add_label=document.createElement("label");
	var name=["第二作者","第三作者","第四作者","第五作者","第六作者","第七作者","第八作者","第九作者","第十作者"];
	if(i<7){
	var label_name=document.createTextNode(name[i]);
	i++;
	}else{
		alert("已达到最大数");
		return true;
	}
	add_label.appendChild(label_name);
	var add_span=document.createElement("span");
	add_span.setAttribute("class","field");
	var add_input=document.createElement("input");
	add_input.setAttribute("type","text");
	a++;
	add_input.setAttribute("name",Number(a));
	add_input.setAttribute("class","smallinput");
	add_input.setAttribute("onblur","getName(this)");
	add_span.appendChild(add_input);
	var academic_t_name=document.getElementById("academic_t_name");
	academic_t_name.parentNode.insertBefore(add_label,academic_t_name);
	academic_t_name.parentNode.insertBefore(add_span,academic_t_name);
} 
//会议论文
function getcName(whichname){
	if(whichname.value){
	var name=whichname.value;
	var c_name=document.getElementById("c_name");
	var c_option=document.createElement("option");
	var c_txt=document.createTextNode(name);
	c_name.appendChild(c_option);
	c_option.appendChild(c_txt)
	}
}
 function addConference(){
	var add_label=document.createElement("label");
	var name=["第二作者","第三作者","第四作者","第五作者","第六作者","第七作者","第八作者","第九作者","第十作者"];
	if(j<7){
	var label_name=document.createTextNode(name[j]);
	j++;
	}else{
		alert("已达到最大数");
		return true;
	}
	add_label.appendChild(label_name);
	var add_span=document.createElement("span");
	add_span.setAttribute("class","field");
	var add_input=document.createElement("input");
	add_input.setAttribute("type","text");
	b++;
	add_input.setAttribute("name",Number(b));
	add_input.setAttribute("class","smallinput");
	add_input.setAttribute("onblur","getcName(this)");
	add_span.appendChild(add_input);
	var conference_t_name=document.getElementById("conference_t_name");
	conference_t_name.parentNode.insertBefore(add_label,conference_t_name);
	conference_t_name.parentNode.insertBefore(add_span,conference_t_name);
}    
//专利
function addPatent(){
	var patent_name = document.getElementById("patent_name");
	var add_label=document.createElement("label");
	var name=["第二发明人","第三发明人","第四发明人","第五发明人","第六发明人","第七发明人","第八发明人","第九发明人","第十发明人"];
	if(k<7){
	var label_name=document.createTextNode(name[k]);
	k++;
	}else{
		alert("已达到最大数");
		return true;
	}
	patent_name.appendChild(add_label);
	add_label.appendChild(label_name);
	var add_span=document.createElement("span");
	add_span.setAttribute("class","field");
	patent_name.appendChild(add_span);
	var add_input=document.createElement("input");
	add_input.setAttribute("type","text");
	c++;
	add_input.setAttribute("name",Number(c));
	add_input.setAttribute("class","smallinput");
	add_span.appendChild(add_input);
} 
//项目
function addProject(){
	var project_name = document.getElementById("project_name");
	var add_label=document.createElement("label");
	var name=["第二参与人","第三参与人","第四参与人","第五参与人","第六参与人","第七参与人","第八参与人"];
	if(l<7){
	var label_name=document.createTextNode(name[l]);
	l++;
	}else{
		alert("已达到最大数");
		return true;
	}
	project_name.appendChild(add_label);
	add_label.appendChild(label_name);
	var add_span=document.createElement("span");
	add_span.setAttribute("class","field");
	project_name.appendChild(add_span);
	var add_input=document.createElement("input");
	add_input.setAttribute("type","text");
	d++;
	add_input.setAttribute("name",Number(d));
	add_input.setAttribute("class","smallinput");
	add_span.appendChild(add_input);
} 

  function Number(x){
//	if(x==2){
//	 var c="secondEdit";
//	}
//	else{
//	 var c=x+"rdEdit";	
//	}
//	return c;

switch(x){
case 2:
  var c="SecondEdit";
  break;
case 3:
  var c="ThirdEdit";
  break;
case 4:
  var c="FourthEdit";
  break;
case 5:
  var c="FifthEdit";
  break;
case 6:
  var c="SixthEdit";
  break;
case 7:
  var c="SeventhEdit";
  break;
case 8:
  var c="EighthEdit";
  break;
case 9:
  var c="NinthEdit";
  break;
default:
  var c="TenthEdit";
  break;
  
}return c;
  }
    var academic_paper=document.getElementById("academic_paper")
	var conference_paper=document.getElementById("conference_paper");
	var patent=document.getElementById("patent");
	var project=document.getElementById("project");
	var show_academic=document.getElementById("show_academic")
	var show_conference=document.getElementById("show_conference");
	var show_patent=document.getElementById("show_patent");
	var show_project=document.getElementById("show_project");
    show_conference.onclick=function(){
    	conference_paper.style.display="block";
    	academic_paper.style.display="none";
    	patent.style.display="none";
    	project.style.display="none";
    	show_conference.setAttribute("class","current");
    	show_academic.setAttribute("class","");
    	show_patent.setAttribute("class","");
    	show_project.setAttribute("class","");
    }
    show_academic.onclick=function(){
    	academic_paper.style.display="block";
    	conference_paper.style.display="none";
    	patent.style.display="none";
    	project.style.display="none";
    	show_academic.setAttribute("class","current");
    	show_conference.setAttribute("class","");
    	show_patent.setAttribute("class","");
    	show_project.setAttribute("class","");
    }
    show_patent.onclick=function(){
    	conference_paper.style.display="none";
    	academic_paper.style.display="none";
    	patent.style.display="block";
    	project.style.display="none";
    	show_conference.setAttribute("class","");
    	show_academic.setAttribute("class","");
    	show_patent.setAttribute("class","current");
    	show_project.setAttribute("class","");
    }
    show_project.onclick=function(){
    	conference_paper.style.display="none";
    	academic_paper.style.display="none";
    	patent.style.display="none";
    	project.style.display="block";
    	show_conference.setAttribute("class","");
    	show_academic.setAttribute("class","");
    	show_patent.setAttribute("class","");
    	show_project.setAttribute("class","current");
    }