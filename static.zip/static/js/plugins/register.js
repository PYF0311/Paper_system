jQuery(document).ready(function(){
								
	///// TRANSFORM CHECKBOX /////							
//	jQuery('input:checkbox').uniform();
//	
//	///// LOGIN FORM SUBMIT /////
//	jQuery('#login').submit(function(){
//	
//		if(jQuery('#username').val() == '' && jQuery('#password').val() == '') {
//			jQuery('.nousername').fadeIn();
//			jQuery('.nopassword').hide();
//			return false;	
//		}
//		if(jQuery('#username').val() != '' && jQuery('#password').val() == '') {
//			jQuery('.nopassword').fadeIn().find('.userlogged h4, .userlogged a span').text(jQuery('#username').val());
//			jQuery('.nousername,.username').hide();
//			return false;;
//		}
//	});
	
	///// ADD PLACEHOLDER /////
	jQuery('#stuname').attr('placeholder','请输入姓名');
	jQuery('#password').attr('placeholder','请输入密码');
	jQuery('#password_confirm').attr('placeholder','请再次确认密码');
	jQuery('#stuid').attr('placeholder','请输入学号');
	jQuery('#major').attr('placeholder','请输入专业班级(如网络1411)');
	jQuery('#firstProf').attr('placeholder','请输入第一导师');
	jQuery('#secondProf').attr('placeholder','请输入第二导师');
	jQuery('#code').attr('placeholder','验证码');
});
